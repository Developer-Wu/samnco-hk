var convert = require('./convert');
module.exports = convert(require('../string'));
