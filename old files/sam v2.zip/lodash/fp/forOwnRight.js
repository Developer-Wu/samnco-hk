var convert = require('./convert'),
    func = convert('forOwnRight', require('../forOwnRight'));

func.placeholder = require('./placeholder');
module.exports = func;
