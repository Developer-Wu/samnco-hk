var convert = require('./convert'),
    func = convert('padCharsStart', require('../padStart'));

func.placeholder = require('./placeholder');
module.exports = func;
