var convert = require('./convert'),
    func = convert('assignInAllWith', require('../assignInWith'));

func.placeholder = require('./placeholder');
module.exports = func;
