var convert = require('./convert'),
    func = convert('flatMap', require('../flatMap'));

func.placeholder = require('./placeholder');
module.exports = func;
